package com.bav.beprepared.service.impl;

import com.bav.beprepared.dto.response.response.StatsResponse;
import com.bav.beprepared.exception.BadRequestException;
import com.bav.beprepared.exception.EntityNotFoundException;
import com.bav.beprepared.model.User;
import com.bav.beprepared.repositor.AlertRepository;
import com.bav.beprepared.repositor.CitizenRepository;
import com.bav.beprepared.repositor.UserRepository;
import com.bav.beprepared.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    private final AlertRepository alertRepository;
    private final CitizenRepository citizenRepository;

    @Override
    @Transactional
    public String createUser(User user) {
        if(userRepository.existsByEmail(user.getEmail())){
            throw new BadRequestException("Já existe usuario com esse e-mail");
        }
        userRepository.save(user);
        return "Usuario criado com sucesso!";
    }

    @Override
    @Transactional(readOnly = true)
    public User getUserById(Long id) {
        return userRepository.findById(id).orElseThrow(()->
                new EntityNotFoundException("Usuario nao encontrado!"));
    }

    @Override
    @Transactional(readOnly = true)
    public StatsResponse getAllStats() {
        return StatsResponse.builder()
                .citizens(citizenRepository.count())
                .totalAlerts(alertRepository.count())
                .activeAlerts(alertRepository.countByActive(true))
                .build()
                ;
    }
}
