package com.bav.beprepared.service;

import com.bav.beprepared.dto.response.response.StatsResponse;
import com.bav.beprepared.model.User;

public interface UserService {
    String createUser(User user);
    User getUserById(Long id);
    StatsResponse getAllStats();


}
