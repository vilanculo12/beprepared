package com.bav.beprepared.service;

import com.bav.beprepared.model.City;
import com.bav.beprepared.model.Province;

import java.util.List;

public interface LocationService {
   
    List<Province>  getAllProvinces();
   
    List<City>  getAllCities();
   
    List<City> getAllCitiesProvinceId(Long ProvinceId);
   
    Province getProvinceById(Long ProvinceId);
     City getCityById(Long CityId);


}
