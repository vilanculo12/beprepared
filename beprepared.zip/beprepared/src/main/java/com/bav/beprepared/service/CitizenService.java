package com.bav.beprepared.service;

import com.bav.beprepared.model.Citizen;
import org.springframework.http.HttpStatus;

import java.util.List;

public interface CitizenService {

    String createCitizen(Citizen citizen, Long cityId);

    List<Citizen> getAllCitizens();

    List<Citizen> getAllCitizensCityId(Long cityId);

    List<Citizen>getAllCitizensByProvinceId(Long provinceId);

    Citizen getCitizenById(Long id);

    String verifyAccount(String otp);




}
