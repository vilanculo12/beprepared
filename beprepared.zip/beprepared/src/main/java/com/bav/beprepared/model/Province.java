package com.bav.beprepared.model;

import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name= "provincias")
public class Province {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
private Long id;
private String designation;
@OneToMany(mappedBy = "province")
    private List<City> cities;

}
