package com.bav.beprepared.control;

import com.bav.beprepared.dto.response.request.AlertRequestDto;
import com.bav.beprepared.dto.response.response.AlertResponseDto;
import com.bav.beprepared.mapper.Mapper;
import com.bav.beprepared.service.AlertServices;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/v1/alerts")
public class AlertController {
    private final Mapper mapper;
    private final AlertServices alertServices;

    @PostMapping("/")
    public ResponseEntity<String> createAlert(@Valid @RequestBody AlertRequestDto alertRequestDto) {
        return new ResponseEntity<>(alertServices.createAlert(
                mapper.mapAlertRequestToModel(alertRequestDto),
                alertRequestDto.getCityId(),
                alertRequestDto.getProvinceId()),
                HttpStatus.CREATED
        );
    }

    @GetMapping
    public ResponseEntity<List<AlertResponseDto>> getAlerts() {
        return ResponseEntity.ok(mapper.mapAlertToResponseDtoList(
                alertServices.getAllAlerts()
        ));
    }
    @GetMapping("/active")
    public ResponseEntity<List<AlertResponseDto>> getAllActiveAlerts() {
        return ResponseEntity.ok(mapper.mapAlertToResponseDtoList(
                alertServices.getAllActiveAlerts()
        ));
    }
    @GetMapping("/city")
    public ResponseEntity<List<AlertResponseDto>> getAllAlertsByCity(@RequestParam  Long cityId){
        return ResponseEntity.ok(mapper.mapAlertToResponseDtoList(
                alertServices.getAllAlertsByCityId(cityId)
        ));
    }
    @GetMapping("/province")
    public ResponseEntity<List<AlertResponseDto>> getAllAlertsByProvince(@RequestParam  Long provinceId){
        return ResponseEntity.ok(mapper.mapAlertToResponseDtoList(
                alertServices.getAllAlertByProvinceId(provinceId)
        ));
    }

    @GetMapping("/{id}")
    public ResponseEntity<AlertResponseDto> getAlertById(@PathVariable  Long id) {
        return ResponseEntity.ok(mapper.mapAlertToResponseDto(
                alertServices.getAlertById(id)
        ));
    }

    @PutMapping("/{id}")
    public ResponseEntity<String> activeAlert(@PathVariable Long id) {
        return ResponseEntity.ok(alertServices.activeAlert(id));
    }


}
