package com.bav.beprepared.dto.response.response;

import lombok.Data;

@Data
public class CityResponseDto {
    private Long id;
    private String designation;
}

