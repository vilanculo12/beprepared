package com.bav.beprepared.model.enums;

public enum Severity {
    EMERGENCIA,
    DESASTRE,
    CALAMIDADE,
    CATACLISMO,
}
