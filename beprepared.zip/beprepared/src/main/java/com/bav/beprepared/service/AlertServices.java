package com.bav.beprepared.service;

import com.bav.beprepared.model.Alert;

import java.util.List;

public interface AlertServices {
    String createAlert(Alert alert, Long cityId, Long provinceId);

    List<Alert> getAllAlerts();

    List<Alert> getAllActiveAlerts();

    List<Alert> getAllAlertsByCityId(Long cityId);

    List<Alert> getAllAlertByProvinceId(Long provinceId);

    Alert getAlertById(Long alertId);

    String activeAlert(Long alertId);
}
