package com.bav.beprepared.dto.response.response;

import lombok.Data;
@Data
public class ProvinceResponseDto {
    private Long id;
    private String designation;
}
